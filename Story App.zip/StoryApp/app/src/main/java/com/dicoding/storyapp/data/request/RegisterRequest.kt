package com.dicoding.storyapp.data.request

data class RegisterRequest(
    val name: String,
    val email: String,
    val password: String
)
