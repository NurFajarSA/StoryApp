package com.dicoding.storyapp.data.model

data class User(
    val name: String,
    val userId: String,
    val token: String
)
